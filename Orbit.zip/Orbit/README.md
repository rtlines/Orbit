# Orbit
Example LaTeX document in the BYUI thesis format.  Some of the text is about showing that orbits are conical.
